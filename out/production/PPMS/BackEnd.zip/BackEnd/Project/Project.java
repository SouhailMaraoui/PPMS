package BackEnd.Project;

import BackEnd.Evaluate.Evaluate;
import treatment.Resource;

import java.util.ArrayList;
import java.util.List;

public class Project
{
	private int id;
	private String label;
	private int value;

	private List<Evaluate> projectEvaluation;

	private List<Resource> resourceRequired;
	private List<Integer> resourcesQuantity;
	
	Project(int id,String label,int idPortfolio)
	{
		this.id=id;
		this.label=label;
		this.resourceRequired=new ArrayList<Resource>();
		this.resourcesQuantity=new ArrayList<Integer>();
	}

	public int getId()
	{
		return id;
	}

	public List<Evaluate> getProjectEvaluation()
	{
		return projectEvaluation;
	}

	public void setProjectEvaluation(List<Evaluate> projectEvaluation)
	{
		this.projectEvaluation = projectEvaluation;
	}

	public float getValue()
	{
		return value;
	}

	public void setValue(int value)
	{
		this.value = value;
	}
	
	public void addResource(Resource resource,int quantity)
	{
		resourceRequired.add(resource);
		resourcesQuantity.add(0);
		this.setRequiredResourceQuantity(resource, quantity);
	}
	
	public void setRequiredResourceQuantity(Resource resource,int quantity)
	{
		int resourceIndex=resourceRequired.indexOf(resource);
		resourcesQuantity.set(resourceIndex, quantity);
	}
	
	public int getRequiredResource(Resource resource)
	{
		int resourceIndex=resourceRequired.indexOf(resource);
		return resourcesQuantity.get(resourceIndex);
	}

	public String getLabel()
	{
		return label;
	}
}
