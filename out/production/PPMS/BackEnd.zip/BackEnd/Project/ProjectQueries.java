package BackEnd.Project;

import BackEnd.Evaluate.Evaluate;
import BackEnd.Evaluate.EvaluateQueries;
import BackEnd.Queries;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProjectQueries
{
    public static void addToDatabase(int id,String label,int idPor,int idType)
    {
        Queries.insertInto("projet",id+",'"+label+"',"+idPor+","+idType);
    }

    public static ResultSet getResultSet()
    {
        return Queries.getResultSet("projet");
    }

    public static List<Project> getProjectsByPortfolio(int idPort)
    {
        List<Project> projects=new ArrayList<>();
        ResultSet rs=Queries.getResultSet("projet");
        try
        {
            while(rs.next())
            {
                int id=rs.getInt(1);
                String label=rs.getString(2);
                int idPortfolio=rs.getInt(3);
                projects.add(new Project(id,label,idPortfolio));
            }
            for(Project project:projects)
            {
                List<Evaluate> projectEvaluation= EvaluateQueries.getProjectEvaluation(project.getId());
                project.setProjectEvaluation(projectEvaluation);
            }

        }
        catch (SQLException e)
        {e.printStackTrace();}

        return projects;
    }

    public static List<String> getProjectsRef()
    {
        List<String> projectsRef=new ArrayList<>();
        ResultSet rs=Queries.getResultSet("projet");
        try
        {
            while(rs.next())
            {
                projectsRef.add(rs.getString(2));
            }
        }
        catch (SQLException e)
        {e.printStackTrace();}

        return projectsRef;
    }
}
