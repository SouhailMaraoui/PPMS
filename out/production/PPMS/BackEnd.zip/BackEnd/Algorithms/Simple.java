package BackEnd.Algorithms;

import BackEnd.Portfolio.Portfolio;
import treatment.Resource;

public class Simple
{
	public static Composition[] simple(Portfolio portfolio)
	{
		int projectsCount=portfolio.GetProjectsCount();
		int compositionsCount=(int)Math.pow(2, projectsCount);
		Composition[] compositions=new Composition[compositionsCount];	
		
		for(int i=0; i<compositionsCount; i++)
		{
			compositions[i]=new Composition();
			for(int j=0; j<projectsCount;j++)
			{
				int power=(int) Math.pow(2,projectsCount-j-1 );
				if((i/power)%2==1)
				{
					compositions[i].AddProject(portfolio.getProject(j));
				}
			}
		}
		
		for(int i=0; i<compositionsCount-1; i++) 
		{
			int maxValueIndex=i;
			for(int j=i+1;j<compositionsCount;j++)
			{
				Composition composition=compositions[j];
				int value=composition.GetValue();
				if(value>compositions[maxValueIndex].GetValue())
				{
						maxValueIndex=j;
				}
			}
			Composition tempComposition=compositions[maxValueIndex];
			compositions[maxValueIndex]=compositions[i];
			compositions[i]=tempComposition;
		}
		
		int resourceCount=portfolio.getResourcesCount();
		int satisfiedProjectCount=compositionsCount;
		
		for(int i=0; i<compositionsCount; i++) 
		{
			Composition composition=compositions[i];
			for(int r=0;r<resourceCount;r++)
			{
				Resource resource=portfolio.getResource(r);
				int resourceRequired=0;
				
				for(int j=0;j<composition.ProjectCount();j++)
				{
					resourceRequired+=composition.GetProject(j).getRequiredResource(resource);
				}
				
				if(resourceRequired>portfolio.getResourceQuantity(resource))
				{
					if(composition.AreReqSatisfied())
					{
						satisfiedProjectCount--;
					}
					composition.SetReqSatisfied(false);
					
				}
			}
		}
		
		Composition[] sortedCompositions=new Composition[satisfiedProjectCount];
		
		int index=0;
		for(int i=0; i<satisfiedProjectCount;i++)
		{
			while(!compositions[index].AreReqSatisfied()) 
			{
				index++;
			}
			sortedCompositions[i]=compositions[index];
			index++;
		}
		
		return sortedCompositions;
	}
}
