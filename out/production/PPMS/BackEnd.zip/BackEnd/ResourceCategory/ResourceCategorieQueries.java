package BackEnd.ResourceCategory;

import BackEnd.Queries;

import java.sql.ResultSet;

public class ResourceCategorieQueries
{
    public static void addToDatabase(int id,String ref,String label)
    {
        Queries.insertInto("categorie",id+",'"+ref+"','"+label+"'");
    }

    public static ResultSet getResultSet()
    {
        return Queries.getResultSet("categorie");
    }
}
